package stepdefinition;

public class logo {

}
