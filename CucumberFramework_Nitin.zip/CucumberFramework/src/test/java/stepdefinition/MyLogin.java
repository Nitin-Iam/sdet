package stepdefinition;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class MyLogin {

	public static WebDriver driver;

	@Given("User is on login page")
	public void user_is_on_login_page() {
		// Write code here that turns the phrase above into concrete actions
		driver = new ChromeDriver();
		driver.get("https://www.saucedemo.com/v1/index.html");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(10));

	}

	@When("User enters valid username and password")
	public void user_enters_valid_username_and_password() {
		driver.findElement(By.id("idToken1")).sendKeys("standard_user");
		driver.findElement(By.id("idToken2")).sendKeys("secret_sauce");
	}

	@When("Click on Login button")
	public void click_on_login_button() {
		driver.findElement(By.id("loginButton_0")).click();
	}

	@Then("User is navigated to HomePage")
	public void user_is_navigated_to_home_page() {
		boolean logo = driver.findElement(By.xpath("//*[@id=\"header_container\"]/div[1]/div")).isDisplayed();
		Assert.assertTrue(logo);
	}

	@Then("close the browser")
	public void close_the_browser() {
		driver.quit();
	}

}
