package pageObject;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class LoginPage {
	public static WebDriver ldriver;

	@FindBy(id = "Email")
	private WebElement txtEmail;

	@FindBy(id = "Password")
	private WebElement txtPassword;

	@FindBy(xpath = "//*[@id=\"main\"]/div/div/div/div[2]/div[1]/div/form/div[3]/button")
	private WebElement login;

	@FindBy(linkText = "Logout")
	WebElement lnkLogout;

	public LoginPage(WebDriver rdriver) {
		ldriver = rdriver;
		PageFactory.initElements(ldriver, this);
	}

	public void setUserNme(String uname) {
		//txtEmail.clear();
		ldriver.findElement(By.xpath("//*[@id=\"Email\"]")).sendKeys(uname);;
		//txtEmail.sendKeys(uname);
	}

	public void setPassword(String pwd) {
		//txtPassword.clear();
		txtPassword.sendKeys(pwd);
	}

	public void clickLogin() {
		login.click();
	}

	public void clickLogout() {
		lnkLogout.click();
	}
}
