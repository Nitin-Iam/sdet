package TestRunner;

import io.cucumber.junit.CucumberOptions;
import io.cucumber.testng.AbstractTestNGCucumberTests;

@CucumberOptions(features = "C:\\Users\\tejat\\eclipse-workspace\\CucumberFramework\\src\\test\\resources\\feature\\LoginFeature.feature",
glue = "src\\test\\java\\stepdefinition\\Steps.java", 
dryRun = false, 
monochrome = true, 
plugin = {"pretty", "html:target/htmlreport.html" }) // html reports

public class CucumberTestRunner extends AbstractTestNGCucumberTests{

}
//AbstractTestNGCucumberTests


